# -*- coding: utf-8 -*-
"""通用制图基底: 投影 / 地形晕渲 / 配色 / 标注避让 / 图廓整饰 / 输出
   用法:  from mapbase import Canvas
"""
import glob
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import matplotlib.transforms as mtransforms
from matplotlib.patches import Polygon as MplPoly, Rectangle
from matplotlib import font_manager
from scipy.ndimage import map_coordinates, label, gaussian_filter

for _p in ['fonts/NotoSansCJKsc-Regular.otf', 'fonts/NotoSansCJKsc-Bold.otf']:
    try:
        font_manager.fontManager.addfont(_p)
    except Exception as e:
        print('字体加载失败', _p, e)
for _p in sorted(glob.glob('/usr/share/fonts/**/*CJK*', recursive=True)):
    try:
        font_manager.fontManager.addfont(_p)
    except Exception:
        pass
_names = {f.name for f in font_manager.fontManager.ttflist}
CJK = 'Noto Sans CJK SC' if 'Noto Sans CJK SC' in _names else \
    (sorted(n for n in _names if 'CJK' in n) or ['DejaVu Sans'])[0]
plt.rcParams['font.family'] = CJK
plt.rcParams['axes.unicode_minus'] = False

# ----------------------------------------------------------------- 分层设色
ANCH = [(-6000, '#051033'), (-4500, '#0a2050'), (-3000, '#113a70'), (-2000, '#17548f'),
        (-1200, '#1f71ab'), (-600, '#2b92c5'), (-250, '#4cb4d8'), (-80, '#7fcfe2'), (-1, '#c9edf2'),
        (0, '#96b07c'), (60, '#9db87f'), (200, '#aec084'), (600, '#c9c890'), (1200, '#dacd9a'),
        (1800, '#cbac7d'), (2600, '#bf906a'), (3600, '#a9745e'), (4600, '#c7a58f'),
        (5600, '#ded5c7'), (7200, '#f8f5f0')]
_AV = np.array([a for a, _ in ANCH], float)
_AC = np.array([matplotlib.colors.to_rgb(c) for _, c in ANCH])


def _znorm(z):
    return np.clip(np.where(z >= 0, 0.42 + 0.58 * (np.clip(z, 0, 7200) / 7200) ** 0.62,
                            0.42 * (1 - (np.clip(-z, 0, 6000) / 6000) ** 0.55)), 0, 1)


ZS = np.concatenate([np.linspace(-6000, -1, 320), np.linspace(0, 7200, 520)])
LUT = np.empty((len(ZS), 3))
for _c in range(3):
    LUT[:, _c] = np.interp(_znorm(ZS), _znorm(_AV), _AC[:, _c])


class Canvas:
    """一张地图:投影 + 地形 + 矢量要素 + 标注"""

    def __init__(self, tag='w', ext=(-6.0, 78.0, 10.0, 145.0), phi=(22.0, 62.0), lam0=75.0, phi0=42.0,
                 fin_w=44.0, dpi=150, botfrac=0.155, proj='albers', bigsize=200000):
        self.tag = tag
        self.lat = np.load(f'lat_{tag}.npy'); self.lon = np.load(f'lon_{tag}.npy')
        self.dem1 = np.memmap(f'dem1_{tag}.dat', dtype=np.float32, mode='r',
                              shape=(len(self.lat), len(self.lon)))
        self.dem0 = np.memmap(f'dem0_{tag}.dat', dtype=np.float32, mode='r',
                              shape=(len(self.lat), len(self.lon)))
        self.drop = np.memmap(f'drop_{tag}.dat', dtype=np.float32, mode='r',
                              shape=(len(self.lat), len(self.lon)))
        self.proj = proj
        if proj == 'albers':
            self.PHI1, self.PHI2, self.LAM0, self.PHI0 = map(np.radians, [phi[0], phi[1], lam0, phi0])
            NN = (np.sin(self.PHI1) + np.sin(self.PHI2)) / 2
            self.NN = NN
            self.CC = np.cos(self.PHI1) ** 2 + 2 * NN * np.sin(self.PHI1)
            self.RHO0 = np.sqrt(self.CC - 2 * NN * np.sin(self.PHI0)) / NN
        self.lam0 = lam0
        lat0, lat1, lon0, lon1 = ext
        self.EXT = dict(lat0=lat0, lat1=lat1, lon0=lon0, lon1=lon1)
        las = np.linspace(lat0, lat1, 80); los = np.linspace(lon0, lon1, 80)
        P = [self.fwd(a, lon0) for a in las] + [self.fwd(a, lon1) for a in las] + \
            [self.fwd(lat1, o) for o in los] + [self.fwd(lat0, o) for o in los]
        CX = np.array([p[0] for p in P]); CY = np.array([p[1] for p in P])
        xm = (CX.max() - CX.min()) * 0.020; ym = (CY.max() - CY.min()) * 0.038
        self.xmin, self.xmax = CX.min() - xm, CX.max() + xm
        self.ymin, self.ymax = CY.min() - ym, CY.max() + ym
        self.DPI = dpi; self.FIN_W = fin_w; self.BOTFRAC = botfrac
        asp = (self.ymax - self.ymin) / (self.xmax - self.xmin)
        mapH = fin_w * asp
        self.FIN_H = mapH / (1 - botfrac)
        self.Wp, self.Hp = int(fin_w * dpi), int(mapH * dpi)
        self.xs = np.linspace(self.xmin, self.xmax, self.Wp)
        self.ys = np.linspace(self.ymax, self.ymin, self.Hp)
        XX, YY = np.meshgrid(self.xs, self.ys)
        self.latg, self.long = self.inv(XX, YY)
        self.px_km = (self.xmax - self.xmin) / self.Wp
        print('画布 %dx%d px, %.2f km/px' % (self.Wp, self.Hp, self.px_km))

    # ------------------------------------------------------------ 投影
    def fwd(self, latd, lond):
        if self.proj == 'eqc':
            R = 6371.0
            return (R * np.radians(np.asarray(lond) - self.lam0),
                    R * np.radians(np.asarray(latd)))
        NN, CC, R = self.NN, self.CC, 6371.0
        rho = np.sqrt(np.maximum(CC - 2 * NN * np.sin(np.radians(latd)), 1e-12)) / NN
        th = NN * (np.radians(lond) - self.LAM0)
        return R * rho * np.sin(th), R * (self.RHO0 - rho * np.cos(th))

    def inv(self, x, y):
        if self.proj == 'eqc':
            R = 6371.0
            return np.degrees(np.asarray(y) / R), np.degrees(np.asarray(x) / R) + self.lam0
        NN, CC, R = self.NN, self.CC, 6371.0
        yy = self.RHO0 - y / R
        rho = np.hypot(x / R, yy)
        th = np.arctan2(x / R, yy)
        v = np.clip((CC - (rho * NN) ** 2) / (2 * NN), -1, 1)
        return np.degrees(np.arcsin(v)), np.degrees(self.LAM0 + th / NN)

    # ------------------------------------------------------------ 底图
    def sample(self, D, order=1):
        r = (self.latg - self.lat[0]) / (self.lat[1] - self.lat[0])
        c = (self.long - self.lon[0]) / (self.lon[1] - self.lon[0])
        return map_coordinates(D, [r.ravel(), c.ravel()], order=order,
                               mode='nearest').reshape(self.latg.shape)

    def terrain(self, bigsize=200000, smooth_sea=True):
        lat, lon = self.lat, self.lon
        _l, _ = label(np.asarray(self.dem0) < -4, structure=np.ones((3, 3)))
        _sz = np.bincount(_l.ravel()); _big = np.zeros(_sz.shape, bool)
        _big[1:] = _sz[1:] > bigsize
        big0 = _big[_l].astype(np.float32); del _l, _sz, _big
        self.big0 = big0
        Z = self.sample(self.dem1).astype(np.float32)
        BG = self.sample(big0, 0) > 0.5
        DP = self.sample(self.drop).astype(np.float32)
        self.BG = BG
        self.is_sea = (Z < 0) & ((DP > 40) | BG)
        Zsm = gaussian_filter(Z, 2.0)
        Z = np.where(self.is_sea, np.minimum(Zsm, -1.0), np.maximum(Z, 0.0)); del Zsm
        if smooth_sea:
            _m = (Z < 0).astype(np.float32)
            _num = gaussian_filter(np.where(Z < 0, Z, 0.0), 7.0)
            _den = gaussian_filter(_m, 7.0)
            Zc = np.where(Z < 0, _num / np.maximum(_den, 1e-6), Z)
        else:
            Zc = Z
        self.Z = Zc
        img = LUT[np.clip(np.searchsorted(ZS, Zc) - 1, 0, len(ZS) - 1)]
        Zs = gaussian_filter(Zc, 0.9)
        gx = np.zeros_like(Zs); gy = np.zeros_like(Zs)
        gx[:, 1:-1] = (Zs[:, 2:] - Zs[:, :-2]) / (2 * self.px_km * 1000)
        gy[1:-1, :] = -(Zs[2:, :] - Zs[:-2, :]) / (2 * self.px_km * 1000)
        slope = np.arctan(np.where(self.is_sea, 0.5, 2.2) * np.hypot(gx, gy))
        asp = np.arctan2(gx, gy)
        alt, azi = np.radians(46), np.radians(315)
        hs = np.sin(alt) * np.cos(slope) + np.cos(alt) * np.sin(slope) * np.cos(azi - asp)
        hs = gaussian_filter(np.clip(hs, 0, 1), 0.8)
        self.img = np.clip(img * (0.42 + 0.72 * hs ** 1.25)[:, :, None], 0, 1)
        # 遮掉投影外接矩形中落在经纬框之外的角落(否则高纬被 clamp 成灰盘/放射纹)
        e = self.EXT
        inside = ((self.latg >= e['lat0']) & (self.latg <= e['lat1']) &
                  (self.long >= e['lon0']) & (self.long <= e['lon1']))
        self.inside = inside
        _bg = np.array(matplotlib.colors.to_rgb('#0e1622'), dtype=np.float32)
        self.img[~inside] = _bg
        self.is_sea = self.is_sea & inside
        self.BG = self.BG & inside
        del Zs, gx, gy, slope, asp, hs
        return self.img

    def setup_axes(self, facecolor='#0e1622'):
        self.fig = plt.figure(figsize=(self.FIN_W, self.FIN_H), dpi=self.DPI, facecolor=facecolor)
        self.ax = self.fig.add_axes([0, self.BOTFRAC, 1, 1 - self.BOTFRAC])
        self.ax.imshow(self.img, extent=(self.xmin, self.xmax, self.ymin, self.ymax), origin='upper',
                       interpolation='bilinear', aspect='equal', zorder=1)
        self.ax.set_xlim(self.xmin, self.xmax); self.ax.set_ylim(self.ymin, self.ymax)
        self.ax.axis('off')
        self.pt2data = (self.DPI / 72.0) * (self.xmax - self.xmin) / self.Wp
        self.placed = []; self.obstacles = []
        return self.ax

    def coastline(self, lw=0.75, dash=True):
        ax = self.ax
        st = 2
        ax.contour(self.xs[::st], self.ys[::st], self.is_sea[::st, ::st].astype(float), [0.5],
                   colors='#1b2a36', linewidths=lw, zorder=6)
        if dash:
            ax.contour(self.xs[::st], self.ys[::st], self.BG[::st, ::st].astype(float), [0.5],
                       colors='#43525e', linewidths=0.55, linestyles='dashed', alpha=0.5, zorder=5)

    def graticule(self, dlat=10, dlon=10, alpha=0.26):
        ax = self.ax
        e = self.EXT
        la0 = int(np.ceil(e['lat0'] / dlat) * dlat); la1 = int(e['lat1'])
        lo0 = int(np.ceil(e['lon0'] / dlon) * dlon); lo1 = int(e['lon1'])
        for la in range(la0, la1 + 1, dlat):
            o = np.linspace(e['lon0'], e['lon1'], 500)
            x, y = self.fwd(np.full_like(o, la), o)
            ax.plot(x, y, color='#ffffff', lw=0.4, alpha=alpha, zorder=7)
        for lo in range(lo0, lo1 + 1, dlon):
            a = np.linspace(e['lat0'], e['lat1'], 500)
            x, y = self.fwd(a, np.full_like(a, lo))
            ax.plot(x, y, color='#ffffff', lw=0.4, alpha=alpha, zorder=7)

    # ------------------------------------------------------------ 标注
    def _bbox(self, p0, p1):
        d0 = self.ax.transData.transform(p0); d1 = self.ax.transData.transform(p1)
        return mtransforms.Bbox([[min(d0[0], d1[0]), min(d0[1], d1[1])],
                                 [max(d0[0], d1[0]), max(d0[1], d1[1])]])

    def reserve(self, la, lo, halfw_pt=30, halfh_pt=30):
        x, y = self.fwd(la, lo)
        self.obstacles.append(self._bbox((x - halfw_pt * self.pt2data, y - halfh_pt * self.pt2data),
                                         (x + halfw_pt * self.pt2data, y + halfh_pt * self.pt2data)))

    def ready(self):
        self.fig.canvas.draw()
        self.rend = self.fig.canvas.get_renderer()

    def fits(self, bb):
        f0 = self.fig.transFigure.inverted().transform((bb.x0, bb.y0))
        f1 = self.fig.transFigure.inverted().transform((bb.x1, bb.y1))
        if f0[0] < 0.004 or f1[0] > 0.996 or f0[1] < 0.004 or f1[1] > 0.996:
            return False
        return all(not bb.overlaps(o) for o in self.placed) and \
            all(not bb.overlaps(o) for o in self.obstacles)

    def put(self, la, lo, txt, fs, fg='#ffffff', halo='#22303a', bold=False, span=1.3,
            zorder=20, lw_factor=0.22, min_lw=2.2, lock=False):
        x, y = self.fwd(la, lo)
        if lock:  # 锁定位置: 强制精确落在给定经纬, 不参与螺旋避让
            t = self.ax.text(x, y, txt, fontsize=fs, color=fg, ha='center', va='center',
                             weight='bold' if bold else 'normal', zorder=zorder,
                             path_effects=[pe.withStroke(linewidth=max(min_lw, fs * lw_factor),
                                                         foreground=halo, alpha=0.92)])
            return t
        p = self.pt2data
        for sc in (1.0, 0.88, 0.78, 0.68):
            ts = fs * sc
            t = self.ax.text(x, y, txt, fontsize=ts, color=fg, ha='center', va='center',
                             weight='bold' if bold else 'normal', zorder=zorder,
                             path_effects=[pe.withStroke(linewidth=max(min_lw, ts * lw_factor),
                                                         foreground=halo, alpha=0.92)])
            for dy in (0, 1.3, -1.3, 2.7, -2.7, 4.2, -4.2, 5.8, -5.8, 7.6, -7.6):
                for dx in (0, 1.9 * span, -1.9 * span, 3.7 * span, -3.7 * span):
                    t.set_x(x + dx * ts * p); t.set_y(y + dy * ts * p)
                    bb = t.get_window_extent(self.rend).expanded(1.05, 1.25)
                    if self.fits(bb):
                        self.placed.append(bb); return t
            t.remove()
        return None

    def alive(self, la, lo):
        i = int(np.clip(np.argmin(np.abs(self.lat - la)), 0, len(self.lat) - 1))
        j = int(np.clip(np.argmin(np.abs(self.lon - lo)), 0, len(self.lon) - 1))
        return float(self.dem1[i, j]) >= 0.0

    # ------------------------------------------------------------ 矢量
    def poly(self, pts, facecolor, alpha=0.30, edgecolor=None, lw=2.0, zorder=10, hatch=None):
        p = np.array([self.fwd(la, lo) for la, lo in pts])
        self.ax.add_patch(MplPoly(p, closed=True, facecolor=facecolor, alpha=alpha,
                                  edgecolor=edgecolor or facecolor, linewidth=lw, zorder=zorder,
                                  hatch=hatch))
        self.ax.add_patch(MplPoly(p, closed=True, facecolor='none', edgecolor='#2b2b2b',
                                  linewidth=lw * 0.40, alpha=0.6, zorder=zorder + 1))

    def line(self, pts, color, lw=2.0, zorder=13, ls=(0, (7, 4)), arrow=True, halo='#20303d'):
        p = np.array([self.fwd(la, lo) for la, lo in pts])
        self.ax.plot(p[:, 0], p[:, 1], color=color, lw=lw, ls=ls, alpha=0.95, zorder=zorder,
                     path_effects=[pe.withStroke(linewidth=lw * 1.6, foreground=halo, alpha=0.55)])
        if arrow and len(p) > 1:
            k = len(p) // 2
            a, b = p[k], p[k + 1] if k + 1 < len(p) else p[-1]
            self.ax.annotate('', xy=a + (b - a) * 0.55, xytext=a + (b - a) * 0.50,
                             arrowprops=dict(arrowstyle='-|>', color=color, lw=lw * 0.8,
                                             mutation_scale=9), zorder=zorder + 1)
        return p

    def dot(self, la, lo, s=13, marker='o', fc='#fdfdfd', ec='#20262c', lw=0.9, zorder=15):
        x, y = self.fwd(la, lo)
        self.ax.scatter([x], [y], s=s, marker=marker, facecolor=fc, edgecolor=ec,
                        linewidths=lw, zorder=zorder)

    # ------------------------------------------------------------ 图廓整饰
    def scale_north(self, la, lo, nla=None, nlo=None, kms=(0, 500, 1000)):
        ax, p = self.ax, self.pt2data
        sy0 = self.fwd(la, lo)[1]
        pts = [self.fwd(la, lo + np.degrees(k / (6371.0 * np.cos(np.radians(la))))) for k in kms]
        self.reserve(la, lo, halfw_pt=260, halfh_pt=95)
        for i in range(len(kms) - 1):
            ax.plot([pts[i][0], pts[i + 1][0]], [sy0, sy0],
                    color=('#ffffff' if i % 2 == 0 else '#2b3a49'), lw=4.5,
                    solid_capstyle='butt', zorder=25)
        for pt, k in zip(pts, kms):
            ax.plot([pt[0], pt[0]], [sy0 - 26 * p, sy0 + 26 * p], color='#e8f0f7', lw=1.3, zorder=26)
            ax.text(pt[0], sy0 + 44 * p, ('0' if k == 0 else str(k)), fontsize=11, color='#22303a',
                    ha='center', va='bottom', zorder=27,
                    path_effects=[pe.withStroke(linewidth=2.6, foreground='#ffffff', alpha=0.95)])
        ax.text(pts[0][0] - 30 * p, sy0, 'km', fontsize=12, color='#22303a', ha='right',
                va='center', zorder=27,
                path_effects=[pe.withStroke(linewidth=2.8, foreground='#ffffff', alpha=0.95)])
        if nla is not None:
            nx, ny = self.fwd(nla, nlo)
            self.reserve(nla, nlo, halfw_pt=110, halfh_pt=150)
            rr = 62 * p
            ax.plot([nx, nx], [ny - rr, ny + rr * 0.55], color='#22303a', lw=2.2, zorder=26,
                    path_effects=[pe.withStroke(linewidth=3.4, foreground='#ffffff', alpha=0.9)])
            ax.add_patch(MplPoly([[nx, ny + rr], [nx - rr * .3, ny + rr * .15],
                                  [nx + rr * .3, ny + rr * .15]], closed=True, facecolor='#22303a',
                                 edgecolor='#ffffff', linewidth=0.8, zorder=27))
            ax.text(nx, ny + rr * 1.25, 'N', fontsize=13, color='#22303a', ha='center', va='bottom',
                    weight='bold', zorder=27,
                    path_effects=[pe.withStroke(linewidth=2.8, foreground='#ffffff', alpha=0.95)])

    def bottom(self, title, subtitle, notes, footnote, legend_title=None, legend=None,
               ncols=5, elevels=True):
        y0 = self.ax.get_position().y0
        axb = self.fig.add_axes([0.012, 0.012, 0.976, y0 - 0.024], zorder=5); axb.axis('off')
        tx = dict(transform=axb.transAxes, va='top', ha='left')
        axb.text(0.000, 0.995, title, fontsize=31, color='#f4f7fb', weight='bold', **tx)
        axb.text(0.001, 0.775, subtitle, fontsize=15, color='#b9d3ea', **tx)
        for i, line in enumerate(notes):
            axb.text(0.001, 0.565 - i * 0.150, line, fontsize=10.3, color='#93a9be', **tx)
        axb.text(0.001, 0.082, footnote, fontsize=9.3, color='#7f93a8', **tx)
        lx = 0.505 if elevels else 0.505
        if elevels:
            axb.text(lx, 0.995, legend_title or '高程 / 水深  (m)', fontsize=13, color='#e8f0f7',
                     weight='bold', **tx)
            bands = [(-5000, '深海　3000–6000'), (-2000, '海盆　1000–3000'), (-500, '浅海　200–1000'),
                     (-80, '近岸　0–200'), (60, '平原　0–200'), (500, '低山　200–1000'),
                     (1500, '中山　1000–2500'), (3200, '高原　2500–4000'), (5200, '高山　4000–5500'),
                     (6500, '极高山 >5500')]
            for i, (zv, lab) in enumerate(bands):
                r, c = divmod(i, 5)
                bx = lx + c * 0.0985; by = 0.600 - r * 0.290
                col = LUT[int(np.clip(np.searchsorted(ZS, zv) - 1, 0, len(ZS) - 1))]
                axb.add_patch(Rectangle((bx, by), 0.019, 0.052, transform=axb.transAxes,
                                        facecolor=tuple(col), edgecolor='#5a6e82', linewidth=0.5,
                                        zorder=6))
                axb.text(bx + 0.0245, by + 0.026, lab, transform=axb.transAxes, fontsize=10,
                         color='#c7d6e4', va='center', ha='left', zorder=6)
        elif legend:
            axb.text(lx, 0.995, legend_title or '政权 / 势力', fontsize=13, color='#e8f0f7',
                     weight='bold', **tx)
            for i, (nm, col) in enumerate(legend):
                r, c = divmod(i, ncols)
                bx = lx + c * (0.485 / ncols); by = 0.640 - r * 0.290
                axb.add_patch(Rectangle((bx, by), 0.019, 0.052, transform=axb.transAxes,
                                        facecolor=col, alpha=0.55, edgecolor='#5a6e82',
                                        linewidth=0.5, zorder=6))
                axb.text(bx + 0.0245, by + 0.026, nm, transform=axb.transAxes, fontsize=10,
                         color='#c7d6e4', va='center', ha='left', zorder=6)
        return axb

    def save(self, out, preview=None, pw=1900):
        self.fig.savefig(out, dpi=self.DPI, facecolor=self.fig.get_facecolor())
        print('saved', out)
        from PIL import Image as _Im
        _im = _Im.open(out); _im.thumbnail((pw, pw), _Im.LANCZOS)
        pv = preview or (out.replace('.png', '.jpg'))
        _im.convert('RGB').save(pv, quality=88)
        print('saved preview', pv)
