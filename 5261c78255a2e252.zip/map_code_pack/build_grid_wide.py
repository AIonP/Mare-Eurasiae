# -*- coding: utf-8 -*-
"""构建大范围 DEM: lon 10..145E, lat -6..78N, 分辨率 0.012° (~1.33km)
   逐瓦片带处理, 用 memmap 输出, 避免一次性占用 GB 级内存"""
import numpy as np, tifffile, os, sys
from scipy.ndimage import map_coordinates

STEP = float(sys.argv[1]) if len(sys.argv) > 1 else 0.012
TAG = sys.argv[2] if len(sys.argv) > 2 else 'w'
LAT0, LAT1, LON0, LON1 = -6.0, 78.0, 10.0, 145.0
D = 'gtif_eu'
X0, X1, Y0, Y1 = 66, 116, 17, 66

lat = np.arange(LAT0, LAT1 + 1e-9, STEP)
lon = np.arange(LON0, LON1 + 1e-9, STEP)
H, Wg = len(lat), len(lon)
print('网格', H, 'x', Wg, '= %.1f M cells, %.0f MB' % (H * Wg / 1e6, H * Wg * 4 / 1e6))

out = np.memmap(f'dem0_{TAG}.dat', dtype=np.float32, mode='w+', shape=(H, Wg))
out[:] = 0

N = 512 * 128
TW = (X1 - X0 + 1) * 512


def load_row(y):
    strip = np.zeros((512, TW), np.int16)
    for x in range(X0, X1 + 1):
        f = f'{D}/{x}_{y}.tif'
        if os.path.exists(f) and os.path.getsize(f) > 1000:
            try:
                a = tifffile.imread(f)
                if a.shape == (512, 512):
                    strip[:, (x - X0) * 512:(x - X0 + 1) * 512] = a
            except Exception:
                pass
    return strip


row0 = np.arange(H)                      # 输出行 -> lat
for y in range(Y0, Y1 + 1):
    ys = [yy for yy in (y - 1, y, y + 1) if Y0 <= yy <= Y1]
    rows = [load_row(yy) for yy in ys]
    top = ys[0]
    strip = np.concatenate(rows, axis=0).astype(np.float32)
    lo = (top - Y0) * 512 + 1
    hi = (top - Y0 + len(ys)) * 512 - 1
    # 该带对应的纬度区间
    def inv_gy(gy):
        yy = (gy + Y0 * 512) / N                # 墨卡托归一化 y
        latr = np.arctan(np.sinh(np.pi * (1 - 2 * yy)))
        return np.degrees(latr)
    # 只处理 row0 中纬度落在该带的行
    lat_lo = inv_gy(hi); lat_hi = inv_gy(lo)
    sel = np.where((lat >= lat_lo) & (lat < lat_hi))[0]
    if len(sel) == 0:
        continue
    sub_lat = lat[sel][:, None] * np.ones((1, Wg))
    sub_lon = np.ones((len(sel), 1)) * lon[None, :]
    lr = np.radians(np.clip(sub_lat, -85, 85))
    gy = (1.0 - np.log(np.tan(np.pi / 4 + lr / 2)) / np.pi) / 2.0 * N - Y0 * 512
    gx = (sub_lon + 180.0) / 360.0 * N - X0 * 512
    vals = map_coordinates(strip, [np.clip(gy - lo, 0, strip.shape[0] - 1).ravel(),
                                   np.clip(gx, 0, TW - 1).ravel()],
                           order=1, mode='nearest')
    out[sel] = vals.reshape(len(sel), Wg).astype(np.float32)
    print(f'  tile row {y}: 输出行 {sel.min()}..{sel.max()}', flush=True)

out.flush()
np.save(f'lat_{TAG}.npy', lat); np.save(f'lon_{TAG}.npy', lon)
print('done dem0_%s' % TAG, out.shape, float(out.min()), float(out.max()))
