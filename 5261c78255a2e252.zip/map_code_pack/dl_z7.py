# -*- coding: utf-8 -*-
"""下载 z=7 GeoTIFF 瓦片, 覆盖 lat -4..78N, lon 10..145E"""
import os, urllib.request, concurrent.futures as cf

D = 'gtif_eu'
os.makedirs(D, exist_ok=True)
X0, X1, Y0, Y1 = 66, 116, 17, 66
need = []
for x in range(X0, X1 + 1):
    for y in range(Y0, Y1 + 1):
        f = f'{D}/{x}_{y}.tif'
        if not (os.path.exists(f) and os.path.getsize(f) > 1000):
            need.append((x, y))
print('需下载', len(need))


def get(xy):
    x, y = xy
    url = f'https://s3.amazonaws.com/elevation-tiles-prod/geotiff/7/{x}/{y}.tif'
    for _ in range(3):
        try:
            with urllib.request.urlopen(url, timeout=90) as r:
                b = r.read()
            if len(b) > 1000:
                open(f'{D}/{x}_{y}.tif', 'wb').write(b)
                return 1
        except Exception:
            pass
    return 0


ok = 0
with cf.ThreadPoolExecutor(16) as ex:
    for i, r in enumerate(ex.map(get, need), 1):
        ok += r
        if i % 100 == 0:
            print(f'  {i}/{len(need)} ok={ok}', flush=True)
print('完成 ok=%d/%d' % (ok, len(need)))
