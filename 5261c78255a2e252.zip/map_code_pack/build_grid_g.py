# -*- coding: utf-8 -*-
"""构建全球 DEM (z=6): lon -170..190E(跨 180 环绕), lat 84N..60S, 0.05° (~5.5km)"""
import numpy as np, tifffile, os
from scipy.ndimage import map_coordinates

STEP = 0.05
LAT0, LAT1, LON0, LON1 = -60.0, 84.0, -170.0, 190.0
D = 'gtif_g'
Y0, Y1 = 0, 45
ZT = 6

lat = np.arange(LAT0, LAT1 + 1e-9, STEP)
lon = np.arange(LON0, LON1 + 1e-9, STEP)
H, Wg = len(lat), len(lon)
print('全球网格', H, 'x', Wg, '= %.1f M cells, %.0f MB' % (H * Wg / 1e6, H * Wg * 4 / 1e6))
out = np.memmap('dem0_g.dat', dtype=np.float32, mode='w+', shape=(H, Wg))
out[:] = 0

N = 512 * (2 ** ZT)          # 32768
TILES = 2 ** ZT              # 64


def load_row(y):
    """加载 z6 的 tile 行 y, 水平方向复制两遍以支持 -170..190 环绕"""
    strip = np.zeros((512, TILES * 512), np.int16)
    for x in range(TILES):
        f = f'{D}/{x}_{y}.tif'
        if os.path.exists(f) and os.path.getsize(f) > 1000:
            try:
                a = tifffile.imread(f)
                if a.shape == (512, 512):
                    strip[:, x * 512:(x + 1) * 512] = a
                    strip[:, (x + TILES) * 512:(x + TILES + 1) * 512] = a
            except Exception:
                pass
    return strip


def inv_gy(gy):
    yy = gy / N
    return np.degrees(np.arctan(np.sinh(np.pi * (1 - 2 * yy))))


for y in range(Y0, Y1 + 1):
    ys = [yy for yy in (y - 1, y, y + 1) if Y0 <= yy <= Y1]
    strip = np.concatenate([load_row(yy) for yy in ys], axis=0).astype(np.float32)
    top = ys[0]
    lo = top * 512 + 1
    hi = (top + len(ys)) * 512 - 1
    lat_lo, lat_hi = inv_gy(hi), inv_gy(lo)
    sel = np.where((lat >= lat_lo) & (lat < lat_hi))[0]
    if len(sel) == 0:
        continue
    sub_lat = lat[sel][:, None] * np.ones((1, Wg))
    sub_lon = np.ones((len(sel), 1)) * lon[None, :]
    lr = np.radians(np.clip(sub_lat, -85, 85))
    gy = (1.0 - np.log(np.tan(np.pi / 4 + lr / 2)) / np.pi) / 2.0 * N
    gx = (sub_lon + 180.0) / 360.0 * N
    vals = map_coordinates(strip, [np.clip(gy - lo, 0, strip.shape[0] - 1).ravel(),
                                   np.clip(gx, 0, strip.shape[1] - 1).ravel()],
                           order=1, mode='nearest')
    out[sel] = vals.reshape(len(sel), Wg).astype(np.float32)
    print(f'  z6 row {y}: 输出行 {sel.min()}..{sel.max()}', flush=True)

out.flush()
np.save('lat_g.npy', lat); np.save('lon_g.npy', lon)
print('done dem0_g', out.shape, float(out.min()), float(out.max()))
