# -*- coding: utf-8 -*-
"""六图渲染: 地理/汉/唐/工业/明反推/现代全球
   用法: python3 m6.py [1|2|3|4|5|6|all]"""
import sys
import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse as MplEllipse, Polygon as MplPoly
from mapbase import Canvas
import data6 as D

W = '/workspace'
HERE = os.path.dirname(os.path.abspath(__file__))

# 自然地球河流名 → 中文标注
NE2CN = {
    'Volga': '伏尔加河', 'Huang He': '黄河', 'Hwang Ho': '黄河', 'Yangtze': '长江',
    'Ganges': '恒河', 'Yamuna': '亚穆纳河', 'Euphrates': '幼发拉底河', 'Tigris': '底格里斯河',
    'Amu  Darya': '阿姆河', 'Syr  Darya': '锡尔河', 'Irtysh': '额尔齐斯河', 'Ili': '伊犁河',
    'Mekong': '湄公河', 'Yenisey': '叶尼塞河', 'Lena': '勒拿河', 'Ob': '鄂毕河',
    'Indus': '印度河', 'Amur': '黑龙江', 'Irrawaddy': '伊洛瓦底江',
    'Brahmaputra': '布拉马普特拉河', 'Salween': '怒江', 'Songhua': '松花江',
    'Sutlej': '萨特莱杰河', 'Naryn': '纳伦河', 'Zarafshon': '泽拉夫尚河', 'Panj': '喷赤河',
    'Kura': '库拉河', 'Araxes': '阿拉斯河', 'Don': '顿河', 'Ural': '乌拉尔河',
    'Dnieper': '第聂伯河', 'Dniester': '德涅斯特河', 'Rhine': '莱茵河', 'Danube': '多瑙河',
    'Po': '波河', 'Rhone': '罗讷河', 'Ebro': '埃布罗河', 'Tigris': '底格里斯河',
}

# 七大内海海峡(图1 高亮)
INNER = {'帕米尔海峡', '印度河峡', '阿姆河海道', '马尼奇海道', '刻赤海峡', '博斯普鲁斯', '达达尼尔海峡'}


def _straits_name(cv, subset=None):
    """仅标海峡名称(图2-6)"""
    lst = subset or D.SNAME
    e = cv.EXT
    for nm, la, lo in lst:
        if la < e['lat0'] or la > e['lat1'] or lo < e['lon0'] or lo > e['lon1']:
            continue
        cv.put(la, lo, nm, 8.0, fg='#bfe6ff', halo='#10222e', zorder=18)


def _seas(cv):
    e = cv.EXT
    for nm, la, lo, fs, col in D.SEAS:
        if la < e['lat0'] or la > e['lat1'] or lo < e['lon0'] or lo > e['lon1']:
            continue
        cv.put(la, lo, nm, fs, fg=col, halo='#0c1a26', zorder=12, span=1.1)


def _places(cv, china=True, skip=None, extra_cn=None, extra_other=None, skip_other=None):
    skip = skip or set()
    skip_other = skip_other or set()
    if china:
        for nm, la, lo, fs in D.CN_PLACES:
            if nm in skip:
                continue
            if fs <= 0:
                continue
            if not cv.alive(la, lo):
                continue
            cv.put(la, lo, nm, fs, fg='#ffd84a', halo='#3a2c00', bold=True, zorder=22)
        # 地图专属补充中国地名
        for nm, la, lo, fs in (extra_cn or []):
            if not cv.alive(la, lo):
                continue
            cv.put(la, lo, nm, fs, fg='#ffd84a', halo='#3a2c00', bold=True, zorder=22)
    else:
        for nm, la, lo, fs in D.OTHER_PLACES:
            if nm in skip_other:
                continue
            if fs <= 0:
                continue
            if not cv.alive(la, lo):
                continue
            cv.put(la, lo, nm, fs, fg='#f2f2f2', halo='#222a30', zorder=21)
        # 地图专属补充非中国地名(白色)
        for nm, la, lo, fs in (extra_other or []):
            if not cv.alive(la, lo):
                continue
            cv.put(la, lo, nm, fs, fg='#f2f2f2', halo='#222a30', zorder=21)


def _powers(cv, key, skip=None):
    skip = skip or set()
    for nm, la, lo, col, fs in D.POWERS[key]:
        if nm in skip:
            continue
        # 势力名放在岸上或近岸, 避免压海太多
        cv.put(la, lo, nm, fs, fg=col, halo='#1a1410', bold=True, zorder=24)


PHYS_COLOR = {'plateau': '#ecd9a6', 'mtn': '#cf9159', 'desert': '#efd98c'}


def _phys(cv):
    """自然地理要素(图1): 高原 / 山脉 / 沙漠"""
    for nm, la, lo, kind, fs in D.PHYS:
        if fs <= 0:
            continue
        if not cv.alive(la, lo):
            continue
        col = PHYS_COLOR[kind]
        cv.put(la, lo, nm, fs, fg=col, halo='#241a0e', bold=(kind == 'mtn'),
               zorder=22, span=1.0)


# 湖泊名(仅标注以下知名湖泊, 其余只绘形不标名)
LAKE_CN = {
    'Lake Balkhash': '巴尔克什湖', 'Issyk-Kul': '伊塞克湖', 'Lake Van': '凡湖',
    'Lake Urmia': '乌尔米耶湖', 'Lake Baikal': '贝加尔湖', 'Qinghai Hu': '青海湖',
    'Lake Zaysan': '斋桑泊', 'Alakol': '阿拉科尔湖', 'Lake Sevan': '塞凡湖',
    'Bosten Hu': '博斯腾湖', 'Ebinur Hu': '艾比湖', 'Hulun Nuur': '呼伦湖',
    'Khövsgöl Nuur': '库苏古尔湖', 'Uvs Nuur': '乌布苏湖', 'Lake Khanka': '兴凯湖',
    'Songhua Hu': '松花湖', 'Tai Hu': '太湖', 'Poyang Hu': '鄱阳湖',
    'Dongting Hu': '洞庭湖', 'Hongze Hu': '洪泽湖', 'Lake Ladoga': '拉多加湖',
    'Lake Onega': '奥涅加湖', 'Lake Tuz': '图兹湖', 'Tonlé Sap': '洞里萨湖',
    'Lake Balaton': '巴拉顿湖', 'Lake Nasser': '纳赛尔湖',
}


def _rivers(cv, min_run=4):
    """真实河流主干(自然地球 10m): 按 dem1 裁切到未淹没河段, 标中文名。
       同一河名只标一次(取最长陆地段)。再补绘自然地球缺失/被淹没的河段。"""
    import pickle
    try:
        rivers = pickle.load(open(os.path.join(HERE, 'rivers_w.pkl'), 'rb'))
    except Exception:
        rivers = []
    best = {}

    def draw(pts, cn, lw=1.5, step_km=6.0):
        # 加密顶点(尤其是手绘补充河段), 使裁切与陆地段计数更精确
        seq = []
        for a, b in zip(pts, pts[1:]):
            dlat = b[0] - a[0]
            dlon = (b[1] - a[1]) * np.cos(np.radians((a[0] + b[0]) / 2))
            d = 111.0 * np.hypot(dlat, dlon)
            n = max(1, int(round(d / step_km)))
            for t in np.linspace(0, 1, n, endpoint=False):
                seq.append((a[0] + dlat * t, a[1] + (b[1] - a[1]) * t))
        if pts:
            seq.append(pts[-1])
        runs, cur = [], []
        for la, lo in seq:
            if cv.alive(la, lo):
                cur.append((la, lo))
            else:
                if cur:
                    runs.append(cur)
                cur = []
        if cur:
            runs.append(cur)
        for run in runs:
            if len(run) >= min_run:
                cv.line(run, '#7fb8e6', lw=lw, zorder=7, ls='solid', arrow=False, halo='#0a1822')
        if cn:
            for run in runs:
                if len(run) >= 6 and (cn not in best or len(run) > len(best[cn][0])):
                    best[cn] = (run, run[len(run) // 2])

    for nm, pts in rivers:
        draw(pts, NE2CN.get(nm))
    for nm, _col, pts in getattr(D, 'SUPP_RIVERS', []):
        draw(pts, nm)
    for cn, (run, mid) in best.items():
        cv.put(mid[0], mid[1], cn, 8.2, fg='#cfe9ff', halo='#0a1822', zorder=9, span=0.9)


def _lakes(cv):
    """真实湖泊(自然地球 10m): 仅绘仍在水面以上(未被淹没)的湖泊。"""
    import pickle
    try:
        lakes = pickle.load(open(os.path.join(HERE, 'lakes_w.pkl'), 'rb'))
    except Exception:
        return
    for nm, poly in lakes:
        cla = sum(p[0] for p in poly) / len(poly)
        clo = sum(p[1] for p in poly) / len(poly)
        if not cv.alive(cla, clo):
            continue
        p = np.array([cv.fwd(la, lo) for la, lo in poly])
        cv.ax.add_patch(MplPoly(p, closed=True, facecolor='#9fd0ff', alpha=0.5,
                                edgecolor='#3a6f95', linewidth=0.8, zorder=7))
        cn = LAKE_CN.get(nm)
        if cn:
            cv.put(cla, clo, cn, 8.6, fg='#dcefff', halo='#0a1822', zorder=9, span=0.9)


def _routes(cv, key):
    for r in D.ROUTES.get(key, []):
        cv.line(r['pts'], r['color'], lw=2.4 if r.get('bold') else 1.8,
                zorder=14, ls=(0, (6, 3)))
        # 路线名
        mid = r['pts'][len(r['pts']) // 3]
        cv.put(mid[0], mid[1], r['name'], 7.6, fg=r['color'], halo='#101a22',
               zorder=17, span=1.0)


# ======================================================= 图1 架空自然地理图
def map1():
    cv = Canvas(tag='w', proj='albers')
    cv.terrain()
    cv.setup_axes()
    cv.ready()
    cv.coastline()
    cv.graticule(dlat=10, dlon=10)
    # —— 主要河流(真实主干, 仅未淹没段) + 湖泊 ——
    _rivers(cv)
    _lakes(cv)
    # —— 洋流(示意, 弱) ——
    cur = [
        [(10, 33), (30, 35), (55, 37), (80, 38), (110, 40), (140, 42)],
        [(143, 72), (140, 55), (138, 40), (130, 30), (122, 22)],
        [(60, 72), (50, 60), (42, 50), (35, 40)],
        [(11, 35), (18, 35), (24, 33)],
    ]
    for p in cur:
        cv.line([(b, a) for a, b in p], '#6fd0ff', lw=1.0, zorder=8,
                ls=(0, (1, 4)), arrow=True, halo='#0a1822')
    cv.put(95, 31, '洋　流', 10, fg='#8fd2f0', halo='#0a1822', zorder=8)
    # —— 海域名称 ——
    _seas(cv)
    # —— 海峡: 内海七海峡高亮(名称+长度+最窄宽), 其余仅标名 ——
    e = cv.EXT
    for nm, la, lo, L, w in D.STRAITS:
        if la < e['lat0'] or la > e['lat1'] or lo < e['lon0'] or lo > e['lon1']:
            continue
        if nm in INNER:
            cv.dot(la, lo, s=24, marker='^', fc='#ff5a3c', ec='#ffffff', lw=1.2, zorder=19)
            txt = '%s\n%d km · 最窄 %s km' % (
                nm, L, ('%.1f' % w).rstrip('0').rstrip('.') if w < 10 else '%d' % w)
            cv.put(la, lo, txt, 9.4, fg='#ffe2d2', halo='#3a0d05', bold=True, zorder=20, span=0.85)
        else:
            cv.dot(la, lo, s=12, marker='^', fc='#7fe0ff', ec='#0c2630', lw=0.8, zorder=19)
            cv.put(la, lo, nm, 7.4, fg='#bfe6ff', halo='#10222e', zorder=18)
    # —— 自然地理要素: 高原 / 山脉 / 沙漠 ——
    _phys(cv)
    cv.scale_north(11.0, 12.0, nla=13.5, nlo=12.0)
    cv.bottom(
        '架空世界 · 内海自然地理总图', '地形 · 主要河流（未淹没段）· 洋流 · 高原山脉沙漠 · 主要海峡（长度 / 最窄处宽度）',
        ['范围：西起地中海中部，东至日本—太平洋，北抵北冰洋，南含马六甲海峡与中南半岛。',
         '▲ 红标为七大内海海峡（帕米尔 / 印度河 / 阿姆河 / 马尼奇 / 刻赤 / 博斯普鲁斯 / 达达尼尔），附长度与最窄宽度；其余海峡仅标名。',
         '河流仅绘出未沉没的河段；本图为纯自然地理图，不绘政权、城市、航线与海冰线。'],
        '内海世界史 · 图1（架空自然地理）', elevels=True)
    cv.save(f'{W}/图1_架空地理图.png')


# ======================================================= 通用历史图
def period(key, no, title, subtitle, notes, legend_title='政权 / 势力',
           skip_cn=None, extra_cn=None, extra_other=None, skip_other=None,
           skip_powers=None, extra_arrows=None):
    cv = Canvas(tag='w', proj='albers')
    cv.terrain()
    cv.setup_axes()
    cv.ready()
    cv.coastline()
    cv.graticule(dlat=10, dlon=10)
    _straits_name(cv)
    if key in D.ROUTES:
        _routes(cv, key)
    _seas(cv)
    _powers(cv, key, skip=skip_powers)
    _places(cv, china=True, skip=skip_cn, extra_cn=extra_cn)
    _places(cv, china=False, extra_other=extra_other, skip_other=skip_other)
    # 地图专属红色箭头(如 河西走廊→撒马尔罕)
    for org, tgt, col in (extra_arrows or []):
        _arrow(cv, org, tgt, col, lw=5.5)
    cv.scale_north(11.0, 12.0, nla=13.5, nlo=12.0)
    leg = [(nm, col) for nm, _, _, col, _ in D.POWERS[key]
           if nm not in (skip_powers or set())]
    cv.bottom(title, subtitle, notes, f'内海世界史 · 图{no}',
              legend_title=legend_title, legend=leg, ncols=4, elevels=False)
    cv.save(f'{W}/图{no}_{title.split("·")[-1].strip()}.png')


def map2():
    # 东汉切片: 北京此时不重要(亦不称"大都"), 不显示; 贵霜北移至印度河海道东岸
    # 去掉渤海国; 现代辽阳(41.27N,123.18E)东汉为辽东郡治"襄平"
    period('han', 2, '古典时期势力图 · 东汉切片', '时间切片：约公元 100 年（东汉）',
           ['海上丝路初成：自长安/敦煌经罗布泊湾、塔里木海、帕米尔海峡直抵地中海。',
            '势力以文字标注，未绘边界；中国相关地名黄色。各海峡仅标名称。'],
           '政权 / 势力',
           skip_cn={'北京', '大都'},
           skip_other={'渤　海　国'},
           extra_cn=[('襄平', 41.27, 123.18, 16)])


def map3():
    # 盛唐切片: 撒马尔罕属唐, 标为中国黄; 屏蔽其白色版本
    period('tang', 3, '中世纪时期势力图 · 盛唐切片', '时间切片：约公元 750 年（唐极盛）',
           ['内海航路贯通：大都—伊斯坦布尔一线连通东亚与地中海；南海航路抵霍尔木兹。',
            '势力以文字标注，未绘边界；中国相关地名黄色。各海峡仅标名称。'],
           '政权 / 势力',
           skip_cn={'北京', '大都'},
           skip_other={'撒马尔罕'},
           extra_cn=[('幽州', 39.9, 116.4, 17), ('营州', 41.27, 123.18, 16),
                     ('撒马尔罕', 39.65, 66.97, 15)])


# ======================================================= 图4 内海工业革命时期
FOUR = {'内海西部强国', '内海东部强国', '内海北部强国', '内海南部强国'}


def _arrow(cv, org, tgt, col, lw=6.0, halo='#1a1410'):
    """醒目宽阔箭头: 粗线 + 大三角箭头头(指向 tgt)"""
    cv.line([org, tgt], col, lw=lw, zorder=22, ls='solid', arrow=False, halo=halo)
    x0, y0 = cv.fwd(*org)
    x1, y1 = cv.fwd(*tgt)
    ang = np.arctan2(y1 - y0, x1 - x0)
    L = lw * 3.4 * cv.pt2data          # 箭头头长
    Wd = lw * 1.9 * cv.pt2data          # 箭头头宽
    bx, by = x1 - L * np.cos(ang), y1 - L * np.sin(ang)
    px, py = -np.sin(ang), np.cos(ang)
    left = (bx + px * Wd / 2, by + py * Wd / 2)
    right = (bx - px * Wd / 2, by - py * Wd / 2)
    cv.ax.add_patch(MplPoly(np.array([(x1, y1), left, right]), closed=True,
                            facecolor=col, edgecolor='#ffffff', linewidth=1.1, zorder=23))


def _ind_four(cv):
    """四大强国: 醒目发源地圆圈 + 醒目宽阔扩张箭头(可多向)"""
    for nm, org, tgts, col in D.INDPOWERS:
        # 发源地: 双层醒目圆圈
        cv.dot(org[0], org[1], s=94, marker='o', fc=col, ec='#ffffff', lw=2.6, zorder=23)
        cv.dot(org[0], org[1], s=30, marker='o', fc='#ffffff', ec=col, lw=2.0, zorder=24)
        # 扩张方向: 每个目标一条醒目宽箭头
        for tgt in tgts:
            _arrow(cv, org, tgt, col, lw=6.0)
        # 势力名置于发源地一侧, 避开箭头
        cv.put(org[0] - 1.6, org[1] - 2.6, nm, 15, fg=col, halo='#140e08',
               bold=True, zorder=26)


def map4():
    cv = Canvas(tag='w', proj='albers')
    cv.terrain()
    cv.setup_axes()
    cv.ready()
    cv.coastline()
    cv.graticule(dlat=10, dlon=10)
    _straits_name(cv)
    # 四大强国(发源地+扩张箭头)
    _ind_four(cv)
    _seas(cv)
    # 其余势力(文字标注)
    for nm, la, lo, col, fs in D.POWERS['ind']:
        if nm in FOUR:
            continue
        cv.put(la, lo, nm, fs, fg=col, halo='#1a1410', bold=True, zorder=24)
    _places(cv, china=True, skip={'大都', '新疏勒'},
            extra_cn=[('奴儿干都司', 53.0, 137.0, 16), ('辽东都司', 41.5, 123.0, 16),
                      ('拉萨', 29.65, 91.13, 13)],
            extra_other=[('新疏勒', 40.0, 77.0, 18)])
    _places(cv, china=False, skip_other={'渤　海　国', '拉萨'})
    # 扩张目标参考名
    for nm, la, lo in [('伏尔加格勒', 48.7, 44.5), ('莫斯科', 55.7, 37.6),
                       ('亚速海', 46.8, 38.2), ('塔里木海东岸', 40.5, 91.0),
                       ('印度（北/中/南）', 20.0, 80.0)]:
        cv.put(la, lo, nm, 9.5, fg='#f2f2f2', halo='#222a30', zorder=21)
    cv.scale_north(11.0, 12.0, nla=13.5, nlo=12.0)
    leg = [(nm, col) for nm, _, _, col in D.INDPOWERS] + \
          [(nm, col) for nm, _, _, col, _ in D.POWERS['ind']]
    cv.bottom('内海工业革命时期势力图', '时间切片：约公元 1600—1800 年（工业革命）',
              ['内海东西南北四大强国鼎立：○ 为发源地，→ 为扩张方向（醒目宽箭头）。',
               '西部强国发源于里海西岸，向亚速海南岸扩张；东部强国发源于新疏勒，向塔里木海东岸扩张；',
               '北部强国据图兰海北岸（稍偏西），向伏尔加格勒与莫斯科双向扩张；南部强国据帕米尔海南岸，向印度全境多向扩张。',
               '周边势力按当时称谓标注：明、日本、俄罗斯（压缩于莫斯科以北—圣彼得堡一带）、奥斯曼。'],
              '内海世界史 · 图4', legend_title='政权 / 势力', legend=leg, ncols=5, elevels=False)
    cv.save(f'{W}/图4_内海工业革命时期势力图.png')


def map5():
    period('ming', 5, '明朝—奥斯曼反推时期势力图', '时间切片：约公元 1550—1650 年',
           ['明军沿内海西征反推，扼帕米尔海峡东口（新疏勒）；奥斯曼守博斯普鲁斯与黑海北岸。',
            '红色箭头示河西走廊指向撒马尔罕；势力以文字标注，未绘边界。各海峡仅标名称。'],
           '政权 / 势力',
           skip_cn={'大都', '新疏勒'},
           skip_other={'平壤', '开城', '撒马尔罕', '拉萨', '渤　海　国'},
           extra_cn=[('平壤', 39.03, 125.75, 13), ('开城', 37.60, 126.55, 12),
                     ('撒马尔罕', 39.65, 66.97, 15), ('新疏勒', 39.6, 75.5, 18),
                     ('拉萨', 29.65, 91.13, 13),
                     ('奴儿干都司', 53.0, 137.0, 16), ('辽东都司', 41.5, 123.0, 16)],
           extra_arrows=[((39.6, 97.5), (39.65, 66.97), '#ff3b30')])


# ======================================================= 图6 现代全球图
def map6():
    cv = Canvas(tag='g', proj='eqc', ext=(-58.0, 82.0, -170.0, 190.0),
                fin_w=40.0, dpi=120, botfrac=0.155)
    cv.terrain()
    cv.setup_axes()
    cv.ready()
    cv.coastline(lw=0.5)
    cv.graticule(dlat=20, dlon=30, alpha=0.22)
    # 五大内海: 锁定真实地理坐标, 不参与自动避让(否则会被邻近标签挤偏)
    LOCK_SEAS = {'塔里木海', '帕米尔海', '图兰海', '里\u3000海', '黑\u3000海'}
    for nm, la, lo, fs, col in D.SEAS:
        if nm in LOCK_SEAS:
            cv.put(la, lo, nm, fs, fg=col, halo='#0c1a26', zorder=21, span=1.1, lock=True)
    # 现代图: 中国西域仅保留 新疏勒 与 敦煌(其余西域城市在粗分辨率下位置偏移/拥挤, 略去)
    # 先占位, 确保二者落在真实经纬位置, 不被后续大号海域标签挤压而漂移/丢失
    for nm, la, lo, fs in [('新疏勒', 40.0, 77.0, 18), ('敦煌', 40.14, 94.66, 18)]:
        cv.put(la, lo, nm, fs, fg='#ffd84a', halo='#3a2c00', bold=True, zorder=22)
    # 海峡(含 马六甲/苏伊士/巴拿马) —— 按用户要求不再标注"台湾海峡"
    for nm, la, lo, L, w in D.STRAITS:
        if la > 80 or la < -58 or nm in ('台湾海峡', '朝鲜海峡', '对马海峡'):
            continue
        cv.dot(la, lo, s=11, marker='^', fc='#7fe0ff', ec='#0c2630', lw=0.7, zorder=19)
        cv.put(la, lo, nm, 7.6, fg='#eafaff', halo='#0a1c26', zorder=20, span=0.9)
    # 海域 —— "日本海"不再标注
    for nm, la, lo, fs, col in D.SEAS:
        if la < -55 or nm in LOCK_SEAS or nm.replace(' ', '').replace('\u3000', '') == '日本海':
            continue
        cv.put(la, lo, nm, fs, fg=col, halo='#0c1a26', zorder=12, span=1.1)
    _powers(cv, 'modern')
    # 现代图: 西域城市在全球粗分辨率下位置拥挤/偏移, 按用户要求仅保留 新疏勒 与 敦煌
    # (二者已在上方优先绘制, 此处跳过以免重复)
    _places(cv, china=True,
            skip={'新疏勒', '敦煌', '疏勒', '龟兹', '于阗', '哈密', '玉门关',
                  '张掖', '河西走廊', '罗布泊湾'})
    # 现代图也标少量世界地名(东京按"中国地名"用黄色)
    for nm, la, lo, fs in [('纽约', 40.7, -74.0, 14), ('伦敦', 51.5, -0.1, 14),
                           ('巴黎', 48.85, 2.35, 13), ('莫斯科', 55.75, 37.6, 14),
                           ('开罗', 30.04, 31.24, 13),
                           ('里约', -22.9, -43.2, 13), ('悉尼', -33.87, 151.2, 13),
                           ('伊斯坦布尔', 41.01, 28.98, 13)]:
        cv.put(la, lo, nm, fs, fg='#f2f2f2', halo='#222a30', zorder=21)
    cv.put(35.68, 139.69, '东京', 14, fg='#ffd84a', halo='#3a2c00', bold=True, zorder=22)
    cv.put(29.65, 91.13, '拉萨', 13, fg='#ffd84a', halo='#3a2c00', bold=True, zorder=22)
    cv.scale_north(-50.0, -60.0, nla=-47.0, nlo=-60.0, kms=(0, 2000, 4000))
    leg = [(nm, col) for nm, _, _, col, _ in D.POWERS['modern']]
    cv.bottom('现代世界格局 · 全球图', '最西为美洲，最东为东太平洋；标注现代主要势力',
              ['海峡含马六甲、苏伊士、巴拿马等；中央亚细亚沉没区（内海）仍清晰可见。',
               '中国相关地名黄色；势力以文字标注，未绘边界。本图分辨率较低。'],
              '内海世界史 · 图6（现代全球）', legend_title='主要势力',
              legend=leg, ncols=5, elevels=True)
    cv.save(f'{W}/图6_现代世界全球图.png')


if __name__ == '__main__':
    which = sys.argv[1] if len(sys.argv) > 1 else 'all'
    order = {'1': map1, '2': map2, '3': map3, '4': map4, '5': map5, '6': map6}
    if which == 'all':
        for f in [map1, map2, map3, map4, map5, map6]:
            f()
    else:
        order[which]()
