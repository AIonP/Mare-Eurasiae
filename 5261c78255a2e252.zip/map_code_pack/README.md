# 史图六张地图绘制代码包

本包包含绘制「史6」系列六张历史/架空世界地图的全部 Python 源码与中文字体。
代码分为三层：**渲染底层 → 主绘图脚本 → 数据 → 预处理/数据构建工具**。

## 目录结构

```
map_code_pack/
├── mapbase.py          渲染底层：Canvas 类、投影、海岸线/经纬网、标签避让与锁定
├── m6.py               主绘图脚本：period() 与 map1~map6()，逐张生成六图
├── data6.py            数据层：政权/势力(POWERS)、地点(PLACE)、海域(SEAS)、海峡(STRAITS)、航线(ROUTES)
├── build_dem.py        数据构建：从 DEM 源生成陆海判定用的 .dat 网格
├── build_grid_g.py     数据构建：生成 global(eqc) 投影网格 lat_g/lon_g
├── build_grid_wide.py  数据构建：生成 wide(Albers) 投影网格 lat_w/lon_w
├── dl_z6.py            数据获取：下载 z6 级地形切片
├── dl_z7.py            数据获取：下载 z7 级地形切片
├── prep_rivers.py      数据构建：预处理河流/湖泊 GeoJSON → .pkl
├── sinks.py            数据处理：汇水/洼地修正（地形闭包）
└── fonts/              Noto Sans CJK SC 中文字体（渲染中文标签必需）
    ├── NotoSansCJKsc-Bold.otf
    └── NotoSansCJKsc-Regular.otf
```

## 运行方式

主入口为 `m6.py`，按图号单独渲染（避免连续重渲染卡死）：

```bash
python3.11 m6.py 1     # 图1
python3.11 m6.py 2     # 图2
...
python3.11 m6.py 6     # 图6
```

生成图片默认写入工作目录（如 `/workspace/图N_*.png`）。

## 依赖

- Python 3.11
- numpy
- matplotlib
- scipy
- Pillow
- tifffile（地形切片读取，仅数据构建/预处理脚本使用）

安装：

```bash
pip install numpy matplotlib scipy Pillow tifffile
```

## 运行期数据文件（未包含在本包内）

代码运行还需以下体积较大的运行期数据（位于原工作区，未打包以减小体积）：

| 文件/目录 | 说明 |
|---|---|
| `dem0_w.dat` / `dem1_w.dat` / `drop_w.dat` | wide(Albers) 投影陆海/地形网格 |
| `dem0_g.dat` / `dem1_g.dat` / `drop_g.dat` | global(eqc) 投影陆海/地形网格 |
| `lat_w.npy` / `lon_w.npy` | wide 网格坐标 |
| `lat_g.npy` / `lon_g.npy` | global 网格坐标 |
| `rivers_w.pkl` / `lakes_w.pkl` | 河流/湖泊矢量（pickle） |
| `ne_10m_rivers_lake_centerlines.geojson` 等 | Natural Earth 矢量源 |
| `gtif/`、`gtif_g/`、`gtif_eu/`、`tiles/` | 地形切片缓存 |

将上述文件与 `map_code_pack/` 放在同一工作目录即可直接运行。

## 说明

- 海域/城市标签采用螺旋自动避让算法；五大内海（塔里木海、帕米尔海、图兰海、里海、黑海）
  使用 `lock=True` 强制精确落位以保证地理对齐。
- `m6.py` 逐图单独运行，避免批量循环时渲染进程卡死。
