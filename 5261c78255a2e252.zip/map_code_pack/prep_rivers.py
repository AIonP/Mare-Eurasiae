# -*- coding: utf-8 -*-
"""预处理自然地球河流/湖泊数据: 裁剪到本图范围(lon 8..147, lat -8..80),
   按 ~8km 加密顶点, 存为 pkl 供 m6 渲染时按地形裁切。"""
import json
import pickle
import numpy as np

LON0, LON1, LAT0, LAT1 = 8.0, 147.0, -8.0, 80.0


def densify(pts, step_km=8.0):
    out = []
    for a, b in zip(pts, pts[1:]):
        dlat = b[0] - a[0]
        dlon = (b[1] - a[1]) * np.cos(np.radians((a[0] + b[0]) / 2))
        d = 111.0 * np.hypot(dlat, dlon)
        n = max(1, int(round(d / step_km)))
        for t in np.linspace(0, 1, n, endpoint=False):
            out.append((a[0] + dlat * t, a[1] + (b[1] - a[1]) * t))
        out.append(b)
    return out


def in_box(la, lo):
    return LAT0 <= la <= LAT1 and LON0 <= lo <= LON1


def collect(path, want_names=None, min_pts=4):
    d = json.load(open(path))
    out = []
    for f in d['features']:
        g = f['geometry']; t = g['type']
        if t == 'LineString':
            segs = [g['coordinates']]
        elif t == 'MultiLineString':
            segs = g['coordinates']
        else:
            continue
        nm = (f['properties'].get('name') or '').strip()
        if want_names is not None and nm not in want_names:
            continue
        if want_names is None and not nm:
            continue  # 仅保留有名字的河流(主干)
        for seg in segs:
            pts = [(la, lo) for lo, la in seg if in_box(la, lo)]
            if len(pts) < 2:
                continue
            fine = densify(pts)
            out.append((nm, fine))
    return out


# ---- 河流(仅命名主干) ----
rivers = collect('ne_10m_rivers_lake_centerlines.geojson')
pickle.dump(rivers, open('rivers_w.pkl', 'wb'))
print('rivers features:', len(rivers))
from collections import Counter
c = Counter(n for n, _ in rivers)
print('命名河流数:', len(c))

# ---- 湖泊(本区主要湖泊, 用于图1) ----
d = json.load(open('ne_10m_lakes.geojson'))
lakes = []
for f in d['features']:
    g = f['geometry']
    nm = (f['properties'].get('name') or '').strip()
    if not nm:
        continue
    if g['type'] == 'Polygon':
        polys = [g['coordinates'][0]]
    elif g['type'] == 'MultiPolygon':
        polys = [p[0] for p in g['coordinates']]
    else:
        continue
    for poly in polys:
        pts = [(la, lo) for lo, la in poly if in_box(la, lo)]
        if len(pts) < 4:
            continue
        # 体量过滤: 经纬度跨度
        lat = [p[0] for p in pts]; lon = [p[1] for p in pts]
        area = (max(lat) - min(lat)) * (max(lon) - min(lon))
        if area < 0.05:   # 太小的不画(避免零碎)
            continue
        lakes.append((nm, pts))
pickle.dump(lakes, open('lakes_w.pkl', 'wb'))
print('lakes features:', len(lakes))
print('湖泊名:', [n for n, _ in lakes])
