# -*- coding: utf-8 -*-
"""对任意网格(lat_TAG/lon_TAG/dem0_TAG)施加沉降核, 输出 drop_TAG / dem1_TAG"""
import numpy as np, sys
from scipy.ndimage import gaussian_filter

TAG = sys.argv[1]

# 复用 sinks.py 中的核列表(跳过前 3 行网格加载代码, 保持单一数据源)
src = open('sinks.py', encoding='utf-8').read().split('\n')
body = '\n'.join(src[3:])
ns = {'np': np, '__builtins__': __builtins__}
exec(body, ns)
K = ns['K']
print('沉降核数量', len(K))

lat = np.load(f'lat_{TAG}.npy'); lon = np.load(f'lon_{TAG}.npy')
H, Wg = len(lat), len(lon)
dem0 = np.memmap(f'dem0_{TAG}.dat', dtype=np.float32, mode='r', shape=(H, Wg))
drop = np.memmap(f'drop_{TAG}.dat', dtype=np.float32, mode='w+', shape=(H, Wg))
drop[:] = 0

BLOCK = 400                      # 按行块处理, 控制内存
for i0 in range(0, H, BLOCK):
    i1 = min(i0 + BLOCK, H)
    sub_lat = lat[i0:i1]
    for lo, la, a, b, d, p in K:
        if la + 1.7 * b < sub_lat.min() or la - 1.7 * b > sub_lat.max():
            continue
        j0 = max(int(np.searchsorted(lon, lo - 1.7 * a)), 0)
        j1 = min(int(np.searchsorted(lon, lo + 1.7 * a)) + 1, Wg)
        if j1 <= j0:
            continue
        LAT = sub_lat[:, None] + 0 * lon[None, j0:j1]
        LON = lon[None, j0:j1] + 0 * sub_lat[:, None]
        r2 = ((LON - lo) / a) ** 2 + ((LAT - la) / b) ** 2
        blk = d * np.exp(-np.clip(r2, 0, 60) ** p)
        np.maximum(drop[i0:i1, j0:j1], blk.astype(np.float32), out=drop[i0:i1, j0:j1])
    print(f'  rows {i0}..{i1}', flush=True)
drop.flush()

dem1 = np.memmap(f'dem1_{TAG}.dat', dtype=np.float32, mode='w+', shape=(H, Wg))
for i0 in range(0, H, BLOCK):
    i1 = min(i0 + BLOCK, H)
    dem1[i0:i1] = gaussian_filter(np.asarray(dem0[i0:i1]) - np.asarray(drop[i0:i1]),
                                  1.2).astype(np.float32)
dem1.flush()
print('done dem1_%s' % TAG, H, Wg)
