# -*- coding: utf-8 -*-
"""下载 z=6 全球瓦片, 覆盖 lat 84N..60S, 全经度"""
import os, urllib.request, concurrent.futures as cf

D = 'gtif_g'
os.makedirs(D, exist_ok=True)
Y0, Y1 = 0, 45
need = [(x, y) for x in range(64) for y in range(Y0, Y1 + 1)
        if not (os.path.exists(f'{D}/{x}_{y}.tif') and os.path.getsize(f'{D}/{x}_{y}.tif') > 1000)]
print('需下载', len(need), flush=True)


def get(xy):
    x, y = xy
    url = f'https://s3.amazonaws.com/elevation-tiles-prod/geotiff/6/{x}/{y}.tif'
    for _ in range(3):
        try:
            with urllib.request.urlopen(url, timeout=120) as r:
                b = r.read()
            if len(b) > 1000:
                open(f'{D}/{x}_{y}.tif', 'wb').write(b)
                return 1
        except Exception:
            pass
    return 0


ok = 0
with cf.ThreadPoolExecutor(24) as ex:
    for i, r in enumerate(ex.map(get, need), 1):
        ok += r
        if i % 200 == 0:
            print(f'  {i}/{len(need)} ok={ok}', flush=True)
print('完成 ok=%d/%d' % (ok, len(need)))
